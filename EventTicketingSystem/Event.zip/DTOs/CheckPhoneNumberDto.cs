﻿namespace EventTicketingSystem.DTOs
{
    public class CheckPhoneNumberDto
    {
        public required string PhoneNumber { get; set; }
    }
}
